﻿using System;
using System.Threading;

namespace Lab1_P3_PI
{
    class Program
    {
        private static object lockObject = new object(); // Để đồng bộ hóa truy cập biến chiaSe
        private static int totalPoints = 1000000; // Tổng số điểm sẽ được tạo
        private static int pointsInsideCircle = 0; // Số điểm rơi vào trong hình tròn

        static void Main(string[] args)
        {
            int numThreads = Environment.ProcessorCount; // Số lõi CPU có sẵn

            Thread[] threads = new Thread[numThreads];
            for (int i = 0; i < numThreads; i++)
            {
                threads[i] = new Thread(ThreadTask);
                threads[i].Start();
            }

            foreach (var thread in threads)
            {
                thread.Join();
            }

            double piApproximation = 4.0 * pointsInsideCircle / totalPoints;
            Console.WriteLine($"Approximated value of Pi: {piApproximation}");
        }

        static void ThreadTask()
        {
            Random random = new Random(Thread.CurrentThread.ManagedThreadId);
            int localPointsInsideCircle = 0;

            for (int i = 0; i < totalPoints; i++)
            {
                double x = random.NextDouble();
                double y = random.NextDouble();

                if (x * x + y * y <= 1)
                {
                    localPointsInsideCircle++;
                }
            }

            lock (lockObject)
            {
                pointsInsideCircle += localPointsInsideCircle;
            }
        }
    }
}