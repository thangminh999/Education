﻿using System;
using System.Threading;

namespace Lab1_P3_N2MT
{
    class Program
    {
        private static int[][] matrix1 = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } }; //1X9 + 2X6 + 3X3, 1X8 + 2X5+ 3 x2
        private static int[][] matrix2 = { { 9, 8, 7 }, { 6, 5, 4 }, { 3, 2, 1 } };
        private static int[][] result = new int[matrix1.Length][matrix2[0].Length];

        static void Main(string[] args)
        {
            int numThreads = 3;
            // Tạo ra 3 luồng
            Thread[] threads = new Thread[numThreads];
            // chunk = 1 nên mỗi luồng sẽ tính toán 1 dòng của ma trận
            int chunk = matrix1.Length / numThreads;
            for (int i = 0; i < numThreads; i++)
            {
                int start = i * chunk;
                int end = (i == numThreads - 1) ? matrix1.Length : (i + 1) * chunk;
                threads[i] = new Thread(() => MultiplyMatrix(start, end));
                threads[i].Start();
            }

            // Đợi tất cả các luồng hoàn thành
            foreach (Thread thread in threads)
            {
                thread.Join();
            }

            // In kết quả
            foreach (int[] row in result)
            {
                foreach (int col in row)
                {
                    Console.Write(col + " ");
                }
                Console.WriteLine();
            }
        }

        private static void MultiplyMatrix(int startRow, int endRow)
        {
            for (int i = startRow; i < endRow; i++)
            {
                for (int j = 0; j < matrix2[0].Length; j++)
                {
                    for (int k = 0; k < matrix1[0].Length; k++)
                    {
                        result[i][j] += matrix1[i][k] * matrix2[k][j];
                    }
                }
            }
        }
    }
}