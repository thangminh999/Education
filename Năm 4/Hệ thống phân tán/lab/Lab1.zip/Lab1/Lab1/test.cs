﻿using System;
using System.Threading;

namespace Lab01
{
    class test
    {
        static void Main(string[] args)
        {
            SharedCounter sharedCounter = new SharedCounter();
            Thread t1 = new Thread(new TieuTrinhCong(sharedCounter).Run);
            Thread t2 = new Thread(new TieuTrinhTru(sharedCounter).Run);
            t1.Start();
            t2.Start();
        }
    }

    class SharedCounter
    {
        private int count;

        public int Count
        {
            get { return count; }
            set { count = value; }
        }
    }

    class TieuTrinhCong
    {
        private SharedCounter sharedCounter;

        public TieuTrinhCong(SharedCounter sharedCounter)
        {
            this.sharedCounter = sharedCounter;
        }

        public void Run()
        {
            for (int i = 0; i < 2500; i++)
            {
                lock (sharedCounter)
                {
                    sharedCounter.Count++;
                    Console.WriteLine("Tieu trinh cong: " + sharedCounter.Count);
                }
            }
        }
    }

    class TieuTrinhTru
    {
        private SharedCounter sharedCounter;

        public TieuTrinhTru(SharedCounter sharedCounter)
        {
            this.sharedCounter = sharedCounter;
        }

        public void Run()
        {
            for (int i = 0; i < 2500; i++)
            {
                lock (sharedCounter)
                {
                    sharedCounter.Count--;
                    Console.WriteLine("Tieu trinh tru: " + sharedCounter.Count);
                }
            }
        }
    }
}