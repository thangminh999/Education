﻿using System;
using System.Threading;

namespace Lab1
{
    class Program
    {
        private int iterations; // Number of iterations
        private string message; // Message to display
        private int delay; // Time delay between displaying messages

        private int count; // Shared variable for two threads

        public Program(int iterations, string message, int delay)
        {
            this.iterations = iterations;
            this.message = message;
            this.delay = delay;
            this.count = 0;
        }

        public void Start()
        {
            // Create threads to increment and decrement the 'count' variable
            ThreadStart incrementMethod = new ThreadStart(TieuTrinhCong);
            ThreadStart decrementMethod = new ThreadStart(TieuTrinhTru);
            Thread incrementThread = new Thread(incrementMethod);
            Thread decrementThread = new Thread(decrementMethod);

            Console.WriteLine("{0} : Starting two new threads.", DateTime.Now.ToString("HH:mm:ss.ffff"));

            // Start the threads
            incrementThread.Start();
            decrementThread.Start();

            // Wait for the threads to finish
            incrementThread.Join();
            decrementThread.Join();
        }

        private void TieuTrinhCong()
        {
            for (int i = 1; i <= 2500; i++)
            {
                Interlocked.Increment(ref count); // Safely increment 'count'
                Console.WriteLine($"{DateTime.Now.ToString("HH:mm:ss.ffff")} : Incremented count to {count}");
            }
        }

        private void TieuTrinhTru()
        {
            for (int i = 1; i <= 2500; i++)
            {
                Interlocked.Decrement(ref count); // Safely decrement 'count'
                Console.WriteLine($"{DateTime.Now.ToString("HH:mm:ss.ffff")} : Decremented count to {count}");
            }
        }

        static void Main(string[] args)
        {
            Program example = new Program(5, "A thread example.", 500);
            example.Start();

            Console.WriteLine("Main method complete. Press Enter to finish.");
            Console.ReadLine();
        }
    }
}