﻿using System;
using System.Linq;
using System.Threading;

namespace Lab1_P3_CL
{
    class Program
    {
        private static Thread evenSortThread;
        private static Thread oddSortThread;

        public static void Main(string[] args)
        {
            int[] arr = { 3, 5, 2, 8, 7, 6, 4, 1, 10, 13, 20, 25, 30 };

            // Create two arrays for even and odd numbers
            int[] evenArr = arr.Where(x => x % 2 == 0).ToArray();
            int[] oddArr = arr.Where(x => x % 2 != 0).ToArray();

            // Create two threads to sort each array separately
            evenSortThread = new Thread(new SortThread(evenArr));
            oddSortThread = new Thread(new SortThread(oddArr));

            // Start both threads
            evenSortThread.Start();
            oddSortThread.Start();

            // Wait for both threads to finish
            evenSortThread.Join();
            oddSortThread.Join();

            // Create a new array containing two sorted subarrays for even and odd elements
            int[][] new_arr = new int[2][];
            new_arr[0] = evenArr;
            new_arr[1] = oddArr;

            int[] flatArr = new int[new_arr.Length * new_arr[0].Length];
            int index = 0;
            for (int i = 0; i < new_arr.Length; i++)
            {
                for (int j = 0; j < new_arr[i].Length; j++)
                {
                    flatArr[index++] = new_arr[i][j];
                }
            }

            // Print the result array
            Console.WriteLine(string.Join(", ", flatArr));
        }

        public class SortThread
        {
            private int[] arr;

            public SortThread(int[] arr)
            {
                this.arr = arr;
            }

            public void Start()
            {
                Thread thread = new Thread(SortArray);
                thread.Start();
            }

            private void SortArray()
            {
                Array.Sort(arr);
            }
        }
    }
}