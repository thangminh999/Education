﻿using System;
using System.Threading;

namespace Lab1_P2
{
    class Program
    {
        private static bool suspended = false;

        public static void Main(string[] args)
        {
            Thread thread = new Thread(DisplayMessage1);
            Console.WriteLine($"{DateTime.Now} : Starting second thread.");
            thread.Start();

            char command = ' ';
            do
            {
                string input = Console.ReadLine();
                if (input.Length > 0)
                    command = char.ToUpper(input[0]);
                else
                    command = ' ';
                switch (command)
                {
                    case 'S': // Tạm hoãn tiểu trình thứ hai.
                        Console.WriteLine($"{DateTime.Now} : Suspending second thread.");
                        suspended = true;
                        break;
                    case 'R': // Phục hồi tiểu trình thứ hai.
                        Console.WriteLine($"{DateTime.Now} : Resuming second thread.");
                        suspended = false;
                        break;
                    case 'I': // Gián đoạn tiểu trình thứ hai.
                        Console.WriteLine($"{DateTime.Now} : Interrupting second thread.");
                        thread.Interrupt();
                        break;
                    case 'E':
                        Console.WriteLine($"{DateTime.Now} : Aborting second thread.");
                        thread.Interrupt();
                        try
                        {
                            thread.Join();
                        }
                        catch (ThreadInterruptedException)
                        {
                        }
                        break;
                }
            } while (command != 'E');


            Console.WriteLine("Main method complete. Press Enter.");
            Console.ReadLine();
        }

        public static void DisplayMessage1()
        {
            while (true)
            {
                try
                {
                    Console.WriteLine($"{DateTime.Now} : Second thread running. Enter (S)uspend, (R)esume, (I)nterrupt, or (E)xit.");
                    Thread.Sleep(2000);
                    while (suspended)
                    {
                        Thread.Sleep(100); // Wait while suspended
                    }
                }
                catch (ThreadInterruptedException)
                {
                    Console.WriteLine($"{DateTime.Now} : Second thread interrupted.");
                }
            }
        }
    }
}
