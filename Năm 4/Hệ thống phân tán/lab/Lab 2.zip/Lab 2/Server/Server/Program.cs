﻿using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

class Server
{
    static void Main(string[] args)
    {
        IPEndPoint iep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 2010);
        Socket server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        server.Bind(iep);
        server.Listen(10);
        Console.WriteLine("Cho ket noi tu client");
        //***********************************
        while (true)
        {
            Socket client = server.Accept();
            Console.WriteLine("Chap nhan ket noi tu:{0}", client.RemoteEndPoint.ToString());

            Thread clientThread = new Thread(() => handleClient(client));
            clientThread.Start();
        }
    }

    static void handleClient(Socket client)
    {
        NetworkStream ns = new NetworkStream(client);
        StreamReader sr = new StreamReader(ns);
        StreamWriter sw = new StreamWriter(ns);
        sw.AutoFlush = true;

        string welcome = "Chao ban den voi Server";
        sw.WriteLine(welcome);

        // Tao 2 luong gui, nhan tin nhan
        Thread sendThread = new Thread(() => SendMessage(client, sw));
        Thread receiveThread = new Thread(() => ReceiveMessage(client, sr));

        sendThread.Start();
        receiveThread.Start();

        // Doi 2 luong chay
        sendThread.Join();
        receiveThread.Join();

        // Dong ket noi
        client.Shutdown(SocketShutdown.Both);
        client.Close();
    }

    static void SendMessage(Socket client, StreamWriter sw)
    {
        while (true)
        {
            Console.Write("Nhap tin nhan cua ban: ");
            string send = Console.ReadLine();
            sw.WriteLine(send);

            if (send.ToUpper().Equals("THOAT")) break;
        }
    }

    static void ReceiveMessage(Socket client, StreamReader sr)
    {
        while (true)
        {
            string receive = sr.ReadLine();
            Console.WriteLine($"\nClient gui len: {receive}");
            Console.Write("Nhap tin nhan cua ban: ");
            if (receive.ToUpper().Equals("THOAT")) break;

        }
    }
}