﻿using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Threading;
using System;

class Client
{
    static void Main(string[] args)
    {
        IPEndPoint iep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 2010);
        Socket client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        client.Connect(iep);

        NetworkStream ns = new NetworkStream(client);
        StreamReader sr = new StreamReader(ns);
        StreamWriter sw = new StreamWriter(ns);
        sw.AutoFlush = true;

        string welcome = sr.ReadLine();
        Console.WriteLine("Server gui:{0}", welcome);

        // tao 2 luong gui nhan
        Thread sendThread = new Thread(() => SendMessage(sw));
        Thread receiveThread = new Thread(() => ReceiveMessage(sr));

        sendThread.Start();
        receiveThread.Start();

        // doi 2 luong chay
        sendThread.Join();
        receiveThread.Join();

        // dong ket noi
        client.Close();
    }

    static void SendMessage(StreamWriter sw)
    {
        while (true)
        {
            Console.Write("Nhap tin nhan cua ban: ");
            string send = Console.ReadLine();
            sw.WriteLine(send);

            if (send.ToUpper().Equals("THOAT")) break;
        }
    }

    static void ReceiveMessage(StreamReader sr)
    {
        while (true)
        {
            string receive = sr.ReadLine();
            Console.WriteLine($"\nServer gui: {receive}");
            Console.Write("Nhap tin nhan cua ban: ");
            if (receive.ToUpper().Equals("THOAT")) break;
        }
    }
}